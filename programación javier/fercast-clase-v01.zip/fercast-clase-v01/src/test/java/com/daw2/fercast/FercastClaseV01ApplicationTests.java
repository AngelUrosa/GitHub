package com.daw2.fercast;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FercastClaseV01ApplicationTests {

    @Test
    void contextLoads() {
    }

}
