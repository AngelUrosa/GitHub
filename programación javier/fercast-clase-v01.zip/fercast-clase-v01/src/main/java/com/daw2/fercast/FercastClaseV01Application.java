package com.daw2.fercast;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FercastClaseV01Application {

    public static void main(String[] args) {
        SpringApplication.run(FercastClaseV01Application.class, args);
    }

}
